const canvas = document.getElementById("canvas")
const ctx = canvas.getContext("2d")

const centerX = canvas.width / 2
const centerY = canvas.height / 2

ctx.lineWidth = 2
ctx.strokeStyle = 'black'
ctx.fillStyle = 'yellow'

let gradient = ctx.createLinearGradient(centerX + 30, centerY / 2, centerX + 400, centerY + 100);
gradient.addColorStop(0,"yellow");
gradient.addColorStop(1,"white");

let gradient2 = ctx.createLinearGradient(centerX + 30, centerY / 2, centerX - 400, centerY + 100);
gradient2.addColorStop(0,"yellow");
gradient2.addColorStop(1,"white");

let show_light = true
let direction = true

faro()

setInterval(faro, 5000)

function rectangle(x, y, dimensionX, dimensionY){
    ctx.beginPath()
    ctx.rect(x, y, dimensionX, dimensionY)
    ctx.stroke()
    ctx.fill()
    ctx.closePath()
}

function triangle(){
    ctx.beginPath()
    ctx.save()
    ctx.rotate((Math.PI / 180) * 90);
    ctx.moveTo(75 + 135, 50 - 1000);
    ctx.lineTo(100 + 135, 75 - 1000);
    ctx.lineTo(100 + 135, 25 - 1000);
    ctx.fill()
    ctx.restore()
    ctx.closePath()
}

function light(){
    ctx.beginPath()
    ctx.moveTo(centerX + 30, centerY / 2 + 30)
    ctx.lineTo(centerX + 400, centerY + 100)
    ctx.lineTo(centerX + 400, centerY / 2)
    ctx.lineTo(centerX + 30, centerY / 2 + 5)
    //ctx.stroke()
    ctx.fill()
    ctx.closePath()
}

function light_left(){
    ctx.beginPath()
    ctx.moveTo(centerX - 30, centerY / 2 + 30)
    ctx.lineTo(centerX - 400, centerY + 100)
    ctx.lineTo(centerX - 400, centerY / 2)
    ctx.lineTo(centerX - 30, centerY / 2 + 5)
    //ctx.stroke()
    ctx.fill()
    ctx.closePath()
}

function faro(){

    ctx.clearRect(0, 0 , canvas.width, canvas.height)

    ctx.fillStyle = "blue"
    triangle()

    ctx.fillStyle = "yellow"
    rectangle(centerX - 25, centerY / 2, 50, 50)

    ctx.fillStyle = 'blue'
    rectangle(centerX - 37.5, (centerY / 2) + 50, 75, 10)


    ctx.fillStyle = "white"
    rectangle(centerX - 20, (centerY / 2) + 61, 40, 60)

    ctx.fillStyle = "red"
    rectangle(centerX - 20, (centerY / 2) + 120, 40, 60)

    ctx.fillStyle = "white"
    rectangle(centerX - 20, (centerY / 2) + 180, 40, 60)

    ctx.fillStyle = "red"
    rectangle(centerX - 20, (centerY / 2) + 240, 40, 60)

    ctx.fillStyle = "blue"
    rectangle(centerX - 50, (centerY / 2) + 300, 100, 15)

    if(show_light){
        if(direction){
            ctx.fillStyle = gradient
            light()
        }
        else{
            ctx.fillStyle = gradient2
            light_left()
        }
        direction = !direction
    }

    show_light = !show_light
}