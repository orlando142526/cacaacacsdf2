document.forms[0].onsubmit = (e) => {
    e.preventDefault()
    console.log("submitted")
}